# Output

### Sign Up
![image](https://user-images.githubusercontent.com/86368869/130504536-d592721b-bc36-4cb3-aaea-89b54ee7560e.png)

### Validating Sign up details
![image](https://user-images.githubusercontent.com/86368869/130504316-2dcd4a3b-8ab0-494d-97ed-a27aaee65cbb.png)


### Login

![image](https://user-images.githubusercontent.com/86368869/130502055-6f980087-01ae-474f-89dd-f7bcdee2e763.png)

### Sign Up testing
![image](https://user-images.githubusercontent.com/86368869/130504112-3ce134be-ef37-4559-8924-8f99658d6bf4.png)

### Ordering Food

![image](https://user-images.githubusercontent.com/86368869/130502102-0f3f6bb5-e701-4c1f-8e2a-3a58d32c6fc6.png)

![image](https://user-images.githubusercontent.com/86368869/130502142-5d91e232-3575-491f-bfea-947af251c800.png)

![image](https://user-images.githubusercontent.com/86368869/130502209-7426b080-d9b0-4936-b292-382a2817ec8c.png)

### Viewing Cart Details
![image](https://user-images.githubusercontent.com/86368869/130503018-16d2b161-778d-4e88-8a2b-002ec0e4cee2.png)

![image](https://user-images.githubusercontent.com/86368869/130502501-e89cbe34-e228-4e1c-a60b-6aad8978437c.png)


### Ordering Medicine
![image](https://user-images.githubusercontent.com/86368869/130503379-26425dca-5aeb-4519-a81e-b0c5918c5073.png)

![image](https://user-images.githubusercontent.com/86368869/130503480-3f71bd73-177f-4241-92f0-8e257e31c3f2.png)

### Location Confirmation
![image](https://user-images.githubusercontent.com/86368869/130502797-be159617-5072-4564-800d-d0f11256d77f.png)

### OTP Authentication
![image](https://user-images.githubusercontent.com/86368869/130502872-52d08515-c38a-49d7-9331-37fe9ffbd8d4.png)
