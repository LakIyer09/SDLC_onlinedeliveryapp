# Structural Diagrams(LLD)

## Class Diagram

![ClassDiagram vpd](https://user-images.githubusercontent.com/86341065/130361263-95101930-5ea5-4b73-af81-c138f30d0964.jpg)

## Component Diagram

![image](https://user-images.githubusercontent.com/86233792/130581131-ad8a6e9b-4f3c-4b35-86ba-7f4be947b3e9.png)


