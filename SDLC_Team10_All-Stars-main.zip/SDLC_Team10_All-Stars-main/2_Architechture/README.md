# Architecture

## High Level Design

### Behavioral Usecase Diagram

![image](https://user-images.githubusercontent.com/86233792/130579538-9593a3c6-d984-4034-a11a-6f7e546719c7.png)


### Sequence Diagram

![image](https://user-images.githubusercontent.com/86233792/130580810-2364dc2e-a6bc-4a8f-ab8f-ee771cbe0c3a.png)

### Structural Component Diagram

![image](https://user-images.githubusercontent.com/86233792/130581131-ad8a6e9b-4f3c-4b35-86ba-7f4be947b3e9.png)

## Low Level Design

### Behavioral Activity Diagram

![image](https://user-images.githubusercontent.com/86274176/130584842-27c88c4b-7bdb-4279-a80f-27369c6d9695.png)







### Structural Class Diagram

![ClassDiagram vpd](https://user-images.githubusercontent.com/86341065/130361263-95101930-5ea5-4b73-af81-c138f30d0964.jpg)
