# Introduction

 1. In this project, We have designed a smart delivery app which has the following features:
 
      - Login and Signup
      - Choosing the delivery system (Food or Medicine)
      - Providing the location
      - Cart details and order confirmation
      - OTP authentication
    
2. Using the Smart Delivery App, user can view and order the products easily; first the User is asked to login/signup, once login is successful he/she is prompted to choose the delivery system they want whether food or medicine, based on the entered detail respective data/products is displayed; once the details are entered the cost is displayed and order confirmation is done. 
Once the user receives the product, OTP is verified and the products are delivered.

## Advantages of online delivery system:
1. Makes the ordering process easier
2. Efficient customer and order management
3. Monitor your expenses incurred in real-time
4. Free and cheap marketing
5. The convenience of mobile ordering
6. Stay ahead of the competition
7. Greater reach

# Defining our system
![image](https://user-images.githubusercontent.com/86368869/130381073-f88d9ebf-dfb0-4da2-9010-f3f22e808b92.png)

# Research

![E-Commerce-Sector-Chart-June-2021](https://user-images.githubusercontent.com/86368869/130327405-7fa51aea-a551-46c6-926e-adb4f2e323ed.jpeg)

The Indian E-commerce industry has been on an upward growth trajectory and is expected to surpass the US to become the second largest E-commerce market in the world by 2034. India e-commerce sector will reach US$99 billion by 2024 from US$30 billion in 2019, expanding at a 27% CAGR, with grocery and fashion/apparel likely to be the key drivers of incremental growth. According to Forrester Research, Indian e-commerce sales rose by ~7-8% in 2020. The Indian online grocery market is estimated to reach US$ 18.2 billion in 2024 from US $1.9 billion in 2019, expanding at a CAGR of 57%.

The Indian e-commerce sector is ranked 9th in cross-border growth in the world, according to Payoneer report. Indian e-commerce is projected to increase from 4% of the total food and grocery, apparel and consumer electronics retail trade in 2020 to 8% by 2025. India's e-commerce orders volume increased by 36% in the last quarter of 2020, with the personal care, beauty and wellness (PCB&W) segment being the largest beneficiary. E-commerce sales in India were estimated to increase by only 7-8% in 2020, compared with 20% in China and the US. The e-commerce market is expected to touch the US$ 84-billion mark in 2021 on the back of healthy growth in the Indian organised retail sector.

As most Indians have started shopping online rather than stepping outside their houses, the Indian e-commerce sector witnessed an increase. India's e-commerce festive sale season from October 15 to November 15 in 2020 recorded Rs. 58,000 crore (US$ 8.3 billion) worth of gross sales for brands and sellers, up 65% from Rs. 35,000 crore (US$ 5 billion) last year.

According to Bain & Company report, India’s social commerce gross merchandise value (GMV) stood at ~US$ 2 billion in 2020. By 2025, it is expected to reach US$ 20 billion, with a potentially monumental jump to US$ 70 billion by 2030, owing to high mobile usage. India's e-commerce order volume increased by 36% in the last quarter of 2020, with the personal care, beauty & wellness (PCB&W) segment being the largest beneficiary. Driven by beauty and personal care (BPC), India's live commerce market is expected to reach a gross merchandise value (GMV) of US$ 4-5 billion by 2025.


# Requirements


# Cost and Features
## Cost:
This project is cost effective and cost can be varied depending upon the built and the requirements of the customer. 

# Features:
•	Login credentials- The Entered details are compared with the database and if the credentials matches, the user is successfully logged in.<br/>
•	Signup- The user is asked for the details and they are validated, once validation is complete the details are compared with the database and account of the user is created.<br/>
•	Delivery system - The user can choose the delivery system as food or medicine.<br/>
•	Cart details - The cost of the products is displayed.<br/>
•	Order Confirmation - Order of the user is confirmed.<br/>
•	Location details of the user - The user is asked to enter the location details.<br/>
•	OTP Authentication - Once the user receives the product, they will be asked to provide the OTP; if it matches then the receiver is confirmed and order is delivered.

# SWOT Analysis
![SWOT](https://user-images.githubusercontent.com/86368869/130312834-23bb6ec0-0aa4-43bf-a4b9-5cd1764fa30a.png)

# 4W’s and 1H
## Who:
This is a user friendly application and can be used by all (i.e, students to elderly aged people). They can easily order food or medicine through this and can be received at their door-step.
## What:
This is user friendly application through which people can choose the delivery system they want that is food/medicine. Order is confirmed through verification and the product is delivered.
## When:
During peak hours going to shop and buying food is difficult, so this application can be used and the food is delivered to their doorstep. During pandemic situations where social distancing is highly important, ordering food can be done online through this application.
## Where:
It can be used in all the delivery systems. As the project is portable and user-friendly, it can be easily implemented on the mobile phones, web browsers, systems and TV's. It should overcome all the drawbacks of the traditional systems.
## How:
The user chooses the delivery system and the order is confirmed. Once he receives the product, OTP is verified and the product is delivered at the door-step.

# Detail requirements
## High Level Requirements: 
| ID | Description | Status |
| --- | --- | --- |
HLR01 | Operating System (Windows 10/Linux) | Implemented ✔
HLR02 | Programming language | Implemented ✔
HLR03 | Application should be interactable and easy to use | Implemented ✔
HLR04 | Application should be user friendly | Implemented ✔
HLR05 | Memory feature to prevent lost of data in case of failure | Future 

##  Low level 
| ID | Description | Status |
| --- | --- | --- |
LLR01 | **Cross compatibility:** <br/> The application must be executeable on both windows and linux. <br/> The application should use: <br/> 1. GCC Compiler<br/>2. Build system using Make | Implemented ✔ 
LLR02 | **For Login & Signup:** <br/> 1. The user credentails must be validated<br/>2. Application should be capable of saving the user details to a CSV file<br/>3. The details must be compared with the database and then stored to avoid redendency | Implemented ✔
LLR03 | The User should be able to choose the delivery system: food/medicine and results must be processed accordingly | Implemented ✔ 
LLR04 | The user must be able to see the cart details and confirm the order | Implemented ✔ 
LLR05 | OTP must be verified and then the product should be delivered | Implemented ✔ 

